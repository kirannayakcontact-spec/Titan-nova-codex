# v27 — Finance Core Consolidation

## Goal
Keep money-related controls in one place, reduce duplicate UI, and avoid creating separate future dashboards for the same finance workflow.

## What changed
- Added one main **Finance** tab.
- Removed separate bottom-nav items for **Wallet**, **Withdraw**, and **Pay**.
- Finance tab now contains compact sub-sections:
  - Summary
  - Wallets
  - Payments
  - Withdrawals
- Old internal tab IDs (`wallets`, `payments`, `withdrawals`) remain compatibility aliases and redirect into Finance sub-tabs.
- Added `/api/finance_core_status` for a lightweight summary/status check.
- Simplified bulky Wallet and Payment tab renderers.
- Kept all existing atomic money APIs as the source of truth:
  - `/api/wallet_transaction`
  - `/api/wallet_credit_limit`
  - `/api/wallet_zero_settle`
  - `/api/approve_payment`
  - `/api/reject_payment`
  - `/api/withdrawal_action`

## Removed from visible workflow
- Separate Wallet nav item
- Separate Pay nav item
- Separate Withdraw nav item

## Preserved
- Wallet credit/debit logic
- Payment approve/reject logic
- Withdrawal approve/paid/reject logic
- Money atomicity/idempotency guards
- Existing compatibility routes
- VIP payment submit flow
- WhatsApp withdrawal command flow

## Line count
- v26 `flask_app.py`: 12,695 lines
- v27 `flask_app.py`: 12,532 lines
- Net reduction: 163 lines

## Validation
- `python3 -m py_compile flask_app.py` passed
- `node --check Gateway.js` passed
