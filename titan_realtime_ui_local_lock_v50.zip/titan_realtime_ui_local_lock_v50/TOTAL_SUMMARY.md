# TITAN PATCH SUMMARY — v49 Checkbox Manual Overwrite

Base: v48 Ledger Realtime No Flash

Included fixes preserved:
- Base manual overwrite v41
- Trick source lock v42
- Setup toggle persist v43
- Market protocol/no Setup v44
- Single visibility v45
- Market time-loop order v46
- Input keyboard stability v47
- Ledger realtime no-flash v48

New in v49:
- Results/Settlement checkboxes update local state instantly.
- Results/Settlement checkboxes save through full `/save` manual overwrite path.
- Removed dependency on small checkbox JSON APIs for these toggles.
- Prevents `Unexpected token '<'` HTML-response parse error from blocking checkbox changes.

Install:
```bash
titan update /sdcard/Download/titan_checkbox_manual_overwrite_v49.zip
```


# v50 Realtime UI Local Lock
Checkbox/toggle ON/OFF flapping fixed by local-write lock, stale live-sync response drop, and forced manual-overwrite save hold.
