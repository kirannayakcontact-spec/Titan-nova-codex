# v33 — Ledger Schedule Exact Card Fix

## Problem
When a ledger Intel schedule was set on a specific card, for example `SRIDEVI DAY OPEN`, the Gateway could also send the matching `SRIDEVI DAY CLOSE` card at the same due time.

This happened because older/base market schedule records and duplicate persistent schedule records could be matched by market base/index fallback instead of exact card/stage.

## Fix
- Added exact schedule-card guard in Flask and Gateway.
- A schedule record must match the exact ledger card identity:
  - type: `ank`, `jodi`, `pannel`
  - market key
  - market name
  - OPEN/CLOSE stage when present
- `OPEN` and `CLOSE` schedules are now isolated.
- `/api/bot_schedule` preview and Gateway runtime both use the same exact-card rule.

## Rule
`SRIDEVI DAY OPEN` schedule sends only `SRIDEVI DAY OPEN`.

`SRIDEVI DAY CLOSE` schedule sends only `SRIDEVI DAY CLOSE`.

If Open and Close have different schedule times, each will be sent only at its own time.

## New endpoints
- Flask: `/api/ledger_schedule_exact_card_status`
- Gateway: `/ledger_schedule_exact_card_status`

## Validation
- `python3 -m py_compile flask_app.py`
- `node --check Gateway.js`
