# v28 Market Core Fix + Easy Manager

## Goal
Fix blank Market tab and keep market management simple, strong, and non-duplicated.

## Root cause fixed
After Lite/Core cleanup, the Market tab renderer still referenced Market Manager helper variables/functions that were removed or missing:
- `marketManagerSearch`
- `marketManagerShowDisabled`
- `marketBadge()`
- `marketScanSummaryHtml()`
- `saveMarketRegistry()`
- `addMarketFromManager()`
- market update/delete/restore helpers

That caused a JavaScript `ReferenceError`, so the Market tab could render blank.

## New v28 behavior
- Market tab has a defensive render wrapper. If any future market UI error happens, it shows the exact error instead of blank screen.
- Market add/edit/delete/disable/restore now uses one compact backend action endpoint:
  - `/api/market_action`
- Market status endpoint added:
  - `/api/market_core_status`
- Market registry save prefers Firebase child-path write to `marketRegistry`, avoiding unnecessary full-root overwrite.
- Entry close-time settings are synced after market registry changes.
- Existing routes are kept for compatibility:
  - `/api/market_registry`
  - `/api/market_registry_delete`
  - `/api/market_source_scan`
  - `/api/market_import_from_website`

## Core preserved
- Ledger market order and card binding
- Auto-rate/recovery logic
- Schedule persistence fixes
- Result market selection
- Scrape/chart mapping logic
- Payment/withdrawal/finance consolidation

## Validation
- `python3 -m py_compile flask_app.py`
- `node --check Gateway.js`
