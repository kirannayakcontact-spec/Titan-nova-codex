# INPUT_KEYBOARD_STABILITY_v47

Fix: Android/mobile keyboard hiding after typing one digit/character.

Root cause: render(true), live sync refresh, Market search, target picker search, and other UI re-render calls rebuilt container.innerHTML while an input/textarea was focused. Android closes keyboard when the focused DOM node is destroyed.

Change:
- Added global editable-input guard.
- render(true) is deferred while text/number/search input is focused.
- render(false) still works for intentional navigation/tab switches.
- Target picker re-render is deferred while typing search/manual text.
- Pending render flushes after input blur.
- Manual overwrite Firebase logic remains unchanged.
- Market time-loop order v46 remains unchanged.
