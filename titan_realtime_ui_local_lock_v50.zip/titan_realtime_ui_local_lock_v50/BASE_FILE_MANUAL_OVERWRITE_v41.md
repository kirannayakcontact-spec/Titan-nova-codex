# TITAN BASE FILE MANUAL OVERWRITE v41

Built from the logic in the uploaded base `flask_app.py`.

## Core principle
Admin save is last-write-wins:
- Browser/UI posts the current full state to `/save`.
- Flask accepts admin payloads only.
- Flask writes that payload to Firebase root using `requests.put(...)`.
- No Firebase Data Guard blocks the save.
- No source-of-truth merge preserves old Firebase values over your manual edit.

## Kept from realtime zip
- Full Titan app package structure.
- Gateway.js included.
- Ledger base sync from v39.
- Manual overwrite backup before root save.
- Runtime cache refresh from exact submitted state after save.

## Risk
If an old browser tab saves after you edited from a new tab, the old tab can overwrite Firebase. Use one active admin tab, reload after update, and close old tabs.

## Uploaded base save_to_firebase logic
```python
def save_to_firebase(data):
    try:
        requests.put(get_firebase_url(), json=data, timeout=10)
    except Exception as e:
        print("Firebase Save Error:", e)

```

## Uploaded base /save route logic
```python
@app.route('/save', methods=['POST'])
def save():
    incoming = request.json
    if not incoming: return jsonify({"status": "error"})

    active_id = incoming.get("activeId")
    is_master_saving = (
    active_id in ["admin1", "admin2", "admin3"]
    or "admin1" in incoming.get("profiles", {})
    or "admin2" in incoming.get("profiles", {})
    or "admin3" in incoming.get("profiles", {})
)

    if is_master_saving:
        save_to_firebase(incoming)
        return jsonify({"status": "success"})
    else:
        return jsonify({"status": "rejected", "msg": "Client app is restricted to Read-Only mode."})

```

## Install
```bash
titan update /sdcard/Download/titan_base_manual_overwrite_patch_v41.zip
```

## After install
1. Close old browser tabs.
2. Open http://127.0.0.1:5000
3. Hard refresh/reload once.
4. Edit Ledger/Setup/Market.
5. Save. The current admin state overwrites Firebase.
