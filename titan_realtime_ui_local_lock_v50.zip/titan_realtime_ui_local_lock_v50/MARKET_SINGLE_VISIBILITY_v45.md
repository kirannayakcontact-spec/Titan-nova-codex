# MARKET_SINGLE_VISIBILITY_v45

Change: Setup tab already removed in v44. This patch removes duplicate ANK/JODI/PAN market visibility blocks from the Market Protocol section.

New rule:
- Market Protocol section: only Capital, Day Target, and per-card target/capital caps.
- Market Manager / Single Market Visibility Registry: the only place for market ON/OFF, Ledger, Results, Auto P/F, Schedule, Entries, Open/Close stage controls.
- Manual overwrite behavior remains enabled.
- Firebase Guard remains disabled.
