# FIREBASE MANUAL OVERWRITE v40

Purpose: remove Firebase Data Guard / protected merge behavior for admin saves.

Changes:
- `/save` now writes the posted admin state directly to Firebase.
- Removed v36 root-save guard from the main `save_to_firebase()` path.
- Removed protected source-of-truth merges before admin save.
- Removed ledger timestamp stale-write preservation: manual card update now wins.
- Pre-overwrite backup is still created under `~/titan_state_backups` / configured backup dir.
- Realtime memory cache is refreshed from the exact admin-submitted state after save.

Important:
- This build intentionally allows overwrite. If an old browser tab saves stale data, it can overwrite newer Firebase data.
- Use one active admin tab/session when changing Settings/Market/Ledger for safest results.
