# v34 — Ledger Random Card Colors

## Purpose
Ledger cards no longer look the same. Every card gets a stable, individual color so OPEN/CLOSE and different markets are easy to identify visually.

## What changed
- Added deterministic unique card color generator in the Ledger UI.
- Color seed uses `type + marketKey + index`, so each card gets a different color.
- Future markets automatically receive a color without manual setup.
- Colors are not stored in Firebase; they are generated from the market key, so there is no extra database bloat.
- Core ledger logic, schedule logic, auto-rate/recovery logic, payment/withdrawal/result/WhatsApp logic are untouched.

## Status endpoint
```text
/api/ledger_card_color_status
```

Expected marker:
```json
"ledgerCardColorFix": true
```

## Deploy
```bash
titan update /sdcard/Download/titan_ledger_random_card_colors_v34.zip
titan restart
```
