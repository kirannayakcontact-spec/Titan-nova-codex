# MARKET_TIME_LOOP_ORDER_v46

## Purpose
Market order is now a single canonical time-loop order in every section.

## Rule
1. `SRIDEVI DAY` / `SRIDEV DAY` is always the first market in every market list.
2. All other markets are sorted by their configured Open/Close time.
3. Times before 06:00 are treated as the end of the same business-day loop, so midnight close markets remain at the end.
4. When a new market is added, Ledger/Results/Jodi/Pan/Market Manager arrays are recalculated by the same time-loop order.
5. If the new market belongs between existing Ledger cards, the card is inserted there and old card data/schedules are reindexed by market name.

## Compatibility
- Manual overwrite mode remains active.
- Firebase Guard remains disabled.
- Setup tab remains removed.
- Market visibility remains single-source in Market Manager.
