# TITAN v37 — Real-Time Fast Sync

## Problem
User actions were feeling delayed because UI/server/Gateway were doing slow full state reads and long polling windows.

## Fix
- Added very short Flask realtime state cache.
- Successful root saves refresh the cache immediately.
- Child-path Firebase writes update/clear cache immediately.
- Master UI live sync changed from 5s to 1.2s.
- VIP/user sync changed from 5s to 1.5s.
- Auto-save debounce reduced from 500ms to 180ms.
- Ledger local hold reduced from 12s to 2.5s.
- Gateway schedule poll reduced from 15s to 2s.
- Gateway result/payment outbox poll reduced from 5s/10s to 2s.
- Gateway load/forward poll reduced from 10s to 3s.
- Firebase Data Guard v36 remains active.

## Env controls
- TITAN_REALTIME_FAST_SYNC=1
- TITAN_STATE_CACHE_TTL_MS=900
- TITAN_GATEWAY_STATE_CACHE_TTL_MS=700
- TITAN_SCHEDULE_POLL_MS=2000
- TITAN_RESULT_POLL_MS=2000
- TITAN_PAYMENT_OUTBOX_POLL_MS=2000
- TITAN_LOAD_FORWARDER_POLL_MS=3000

## Status endpoints
- Flask: /api/realtime_sync_status
- Gateway: /realtime_sync_status
