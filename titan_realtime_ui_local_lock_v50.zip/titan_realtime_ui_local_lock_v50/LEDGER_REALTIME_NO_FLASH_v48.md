# LEDGER_REALTIME_NO_FLASH_v48

Fixes ledger old-value flash while editing digits/rates/status.

## Problem
When a user changed a ledger digit/rate/status, an already-running live sync could return an older Firebase snapshot. The UI then briefly showed the old value (for example `123`) before the new committed value (`098`) came back.

## Fix
- Adds an in-memory optimistic ledger patch layer.
- A stale `/api/state` response is overlaid with the current local ledger edit before rendering.
- Live sync responses that started before the latest local mutation no longer repaint the card with old data.
- Local hold time is increased to cover debounced Firebase commits and slow mobile network responses.
- No browser localStorage ledger source-of-truth is reintroduced; Firebase remains final after commit.

## Scope
- Digit box
- Rate box
- PASS / FAIL / SKIP status
- Reset / card unlock
- Auto-rate result on the edited card
- Admin to VIP ledger sync protection

## Base
Includes v47 keyboard stability, v46 market time-loop ordering, v45 single visibility, v44 setup removal, and manual-overwrite save behavior.
