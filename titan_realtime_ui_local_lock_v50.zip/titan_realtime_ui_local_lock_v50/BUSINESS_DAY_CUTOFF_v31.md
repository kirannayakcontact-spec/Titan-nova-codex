# v31 Business Day Cutoff Fix

## Problem
Calendar midnight ke baad app next date pakad raha tha. Main Bazar/late-night market me 00:00 ke baad entries/results/ledger/schedule next day loop me chale jaate the.

## Fix
Business day cutoff add kiya gaya. Default cutoff: **06:00 Asia/Kolkata**.

Rule:
- 00:00 se 05:59 tak app **previous business date** use karega.
- 06:00 ke baad app **fresh next business date** start karega.

Example:
- 2026-07-04 01:30 AM => business date 2026-07-03
- 2026-07-04 05:59 AM => business date 2026-07-03
- 2026-07-04 06:00 AM => business date 2026-07-04

## Affected flows
- Ledger current date
- Auto-rate/recovery date
- WhatsApp entry date
- Result scrape/poll date
- Bot schedule date locks
- Market locks
- WhatsApp safety daily counters

## Config
Default is 6 AM. Change in Termux `.bashrc` if needed:

```bash
export TITAN_BUSINESS_DAY_CUTOFF_HOUR="6"
```

For 5 AM:

```bash
export TITAN_BUSINESS_DAY_CUTOFF_HOUR="5"
```

Restart required after change.

## Status endpoints
Flask:

```text
/api/business_day_cutoff_status
```

Gateway:

```text
/business_day_cutoff_status
```

## Validation
```bash
python3 -m py_compile flask_app.py
node --check Gateway.js
```
