# REALTIME STABILITY LOCK v38

Applied fixes:

1. Firebase root save now caches the exact committed/merged candidate, not the stale browser payload.
2. `/api/state`, `/save`, ledger and market APIs now return no-store/no-cache headers.
3. Initial app boot state fetch now uses `cache:'no-store'` with a cache-busting query.
4. Backend realtime cache default reduced from 900ms to 250ms.
5. Gateway realtime cache default reduced from 700ms to 250ms and Firebase GETs send no-cache headers.
6. Ledger card commits now track in-flight Firebase writes with a counter, so live sync cannot overwrite digits/rates/status while a write is still settling.
7. If a ledger Firebase commit fails, the UI holds the local card for 10 seconds instead of allowing immediate live-sync revert.
8. Master live sync now compares market registry, ledger schedules and key settings too, so tab controls sync from Firebase instead of silently staying stale.
9. Master/VIP live sync now ignores non-OK `/api/state` responses instead of trying to render broken/unauthorized payloads.

Primary target symptoms fixed:
- digit/rate/status disappearing and coming back after 1 second
- pass/fail/T1/T2/T3 reverting after refresh/live sync
- ledger auto-rate suggestion being overwritten by stale state
- market/schedule settings not reflecting across tabs/devices quickly
