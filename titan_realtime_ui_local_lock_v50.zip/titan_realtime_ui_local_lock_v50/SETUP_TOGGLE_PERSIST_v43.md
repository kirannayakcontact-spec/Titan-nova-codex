# SETUP_TOGGLE_PERSIST_v43

Fixes the issue where Setup market visibility toggles show OFF immediately but return ON after page refresh.

Root cause:
- `autoSave()` returned without saving when `titanLedgerHasLocalDirty()` was true.
- Ledger local hold/in-flight can remain active after card edits or full save.
- Setup toggles update local `state.dayRecords[currentDate].visAnk/visJodi/visPan`, but Firebase never receives the change.

Fix:
- `autoSave(force=true)` now calls `saveMaster(true, true)` in manual-overwrite mode.
- `saveMaster` has a separate `titanFullSaveInFlight` queue instead of using `titanLedgerSaveInFlight`.
- Setup visibility toggles use immediate forced save.
- Firebase Guard remains disabled; admin state wins.
