# TITAN Realtime Ledger Base Sync v39

## Patch purpose
This build uses the uploaded `flask_app(4).py` compact Ledger card layout as the Ledger base, while preserving v38 realtime stability protections.

## Fixed / changed
- Ledger card UI rebuilt as compact base-style cards.
- Digits, Invest, T1/T2/T3, PASS/FAIL/SKIP, Copy, Intel and Result controls stay on the working Ledger base flow.
- Market-key binding preserved so add/delete/reorder market does not shift old card records.
- Atomic `/api/ledger_card_update` Firebase child-path save preserved.
- Realtime dirty lock preserved so typing, delete, T1/T2/T3, PASS/FAIL, and auto-rate do not revert after live sync.
- Daily schedule controls kept compact inside each Ledger card.
- Full app tabs, Gateway.js and Firebase guard from v38 are preserved.

## Run
```bash
python flask_app.py
```
Second Termux session:
```bash
node Gateway.js
```
