# TITAN v50 — Realtime UI Local Lock

## Problem
Checkbox/toggle ko OFF karte hi UI local state update ho rahi thi, lekin ek live-sync request jo click se pehle start hui thi purana Firebase snapshot laakar control ko wapas ON kar deti thi. Save complete hone ke baad phir OFF aata tha, isliye ON/OFF/ON/OFF flicker/flapping dikhta tha.

## Fix
- All checkbox/radio changes now set a short local-write lock before inline onchange runs.
- Master live-sync skips while a local UI write is active.
- In-flight stale sync responses are dropped before they can overwrite local toggle state.
- Forced manual-overwrite saves extend the lock until Firebase has time to become the source of truth.
- Settlement/result/market/settings toggles are covered.

## Preserved
- Manual overwrite mode remains active.
- Firebase Guard is not restored.
- v49 checkbox JSON error fix remains.
- v48 ledger no-flash fix remains.
- v47 keyboard stability remains.
- v46 market time-loop ordering remains.
