# v29 — Market Direct Add + Website Scan Fix

## What changed

- Market tab now supports direct full market add from one compact form.
- Direct add saves the market into the central market registry, which feeds Ledger, Results, Auto P/F, and Schedule.
- Website scan list now shows real market names instead of `[object Object]`.
- Save Selected now sends the correct payload (`names` + `selectedMarkets`) and backend accepts both formats.
- Added `/api/market_direct_add_status`.

## How to add a market

Open Market tab → Direct Add Full Market:

1. APP MARKET NAME: name used inside app.
2. WEBSITE NAME / RESULT NAME: exact name from result website.
3. Open HH:MM.
4. Close HH:MM.
5. Chart/Result URL optional.
6. Keep Ledger, Results, Auto P/F, Schedule enabled.
7. Press Direct Add in All.

## Safety

- Old market history is not deleted.
- Single source of truth remains `marketRegistry`.
- Core Ledger/Payment/Withdrawal/Result logic not changed.
