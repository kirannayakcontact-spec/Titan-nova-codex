# TITAN v36 — Firebase Data Guard / Reset Protection

## Problem
User reported that Firebase data which existed in the morning disappeared later. The main risk paths were:

- Flask `migrate_and_get_state()` could create and save a default state if Firebase returned empty/unreadable.
- Legacy Flask `save_to_firebase()` used full-root PUT after loading state, so stale browser/API payloads could replace live data.
- Gateway `saveFirebaseState()` could still continue toward a root PUT when Firebase read/merge failed.
- Money atomic root CAS could initialize an empty root if Firebase read returned null.

## Fixes

### Flask
- Added `FIREBASE_DATA_GUARD_VERSION = 2026-07-03-firebase-data-guard-v36`.
- `load_from_firebase()` now records load status and treats empty/null root as critical.
- Default state is no longer auto-saved when Firebase is empty/unreadable.
- If Firebase is empty/unreadable and a valid `last_known_good.json` exists, app serves backup state without writing Firebase.
- Every `save_to_firebase()` call is now routed through guarded CAS root save.
- Unguarded direct root PUT is blocked unless `TITAN_ALLOW_UNGUARDED_ROOT_PUT=1` is explicitly set.
- Protected collection loss guard added for:
  - profiles
  - wallets
  - walletTransactions
  - payments
  - withdrawals
  - entries
  - ledgerSchedules
  - resultRecords
  - settlementRecords
  - marketRegistry
  - marketLocks
  - auditLog
  - paymentOutbox
  - loadForwarderOutbox
  - spamGuardEvents
  - whatsappSafetyTargets
  - whatsappSafetyEvents
  - resultTargets
  - loadForwarder
  - entrySettings
  - resultSettings
  - paymentMethods
  - withdrawalSettings
  - walletSettings
  - spamGuardSettings
  - whatsappSafetySettings
  - moneyIdempotency
  - gatewayDurability
- Money atomicity root save now blocks if Firebase root is empty/unreadable.

### Gateway
- Added same protected collection loss guard before any Gateway root save.
- Gateway no longer root-saves if Firebase read returns empty/unreadable unless `TITAN_FIREBASE_ALLOW_EMPTY_INIT=1` is set.
- Gateway root save keeps CAS ETag write and now also applies generic protected collection merge.

## Status endpoints

Flask:

```bash
curl -i -H "X-Titan-Admin-Token: $TITAN_ADMIN_TOKEN" http://127.0.0.1:5000/api/firebase_data_guard_status
```

Gateway:

```bash
curl -i -H "X-Titan-Admin-Token: $TITAN_ADMIN_TOKEN" http://127.0.0.1:3000/firebase_data_guard_status
```

Expected markers:

```json
{
  "firebaseDataGuard": true,
  "guardedRootSaves": true,
  "casRootPut": true,
  "emptyFirebaseDefaultOverwriteBlocked": true
}
```

## Important
For existing apps, do not set `TITAN_FIREBASE_ALLOW_EMPTY_INIT=1`.
Use it only one time for a brand-new empty Firebase database.
