# v44 — Market Protocol No Setup Tab

Changes:
- Removed the admin Setup tab from bottom navigation.
- Moved Capital, Day Target, ANK/JODI/PAN card protocol targets, and market visibility controls into the Market tab.
- Market tab is now the central place for protocol + market registry + per-market routing.
- Manual overwrite save behavior remains active; Firebase Guard remains disabled.
- Toggle/target edits call forced admin settings save so refresh should retain changes.
