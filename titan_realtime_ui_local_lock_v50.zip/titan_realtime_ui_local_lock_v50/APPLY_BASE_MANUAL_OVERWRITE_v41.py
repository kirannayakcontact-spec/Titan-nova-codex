#!/usr/bin/env python3
"""Apply TITAN v41 base-file manual overwrite save logic to a flask_app.py.
Usage: python APPLY_BASE_MANUAL_OVERWRITE_v41.py flask_app.py
"""
import re, sys, pathlib
path = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'flask_app.py')
s = path.read_text(encoding='utf-8')
pattern = r"@app\.route\('/save', methods=\['POST'\]\)\ndef save\(\):\n(?:    .*\n)+?@app\.route\('/api/submit_payment', methods=\['POST'\]\)"
new = '''@app.route('/save', methods=['POST'])
def save():
    incoming = request.json
    if not incoming:
        return jsonify({"status": "error", "message": "No JSON payload received", "manualOverwrite": True}), 400

    active_id = incoming.get("activeId")
    is_master_saving = (
        active_id in ["admin1", "admin2", "admin3"]
        or "admin1" in incoming.get("profiles", {})
        or "admin2" in incoming.get("profiles", {})
        or "admin3" in incoming.get("profiles", {})
    )

    if is_master_saving:
        saved = save_to_firebase(incoming, "base_file_manual_overwrite_v41")
        if not saved:
            return jsonify({"status": "error", "message": "Firebase manual overwrite save failed.", "manualOverwrite": True}), 500
        return jsonify({"status": "success", "manualOverwrite": True, "firebaseGuardDisabled": True})
    else:
        return jsonify({"status": "rejected", "msg": "Client app is restricted to Read-Only mode."})

@app.route('/api/submit_payment', methods=['POST'])'''
s2, n = re.subn(pattern, new, s, count=1)
if n != 1:
    raise SystemExit('Could not find /save route to patch')
path.write_text(s2, encoding='utf-8')
print('Patched', path)
