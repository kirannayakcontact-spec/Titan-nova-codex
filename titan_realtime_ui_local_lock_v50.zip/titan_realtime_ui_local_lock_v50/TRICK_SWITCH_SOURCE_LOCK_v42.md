# TRICK_SWITCH_SOURCE_LOCK_v42

Problem fixed:
- Scrape/manual/smart-paste se 10 original digits aate the.
- T1 click ke baad visible box 5 digits ban jata tha.
- Uske baad T2/T3 click karne par app visible 5 digits ko source maan leta tha, isliye trick switch fail hota tha.

New logic:
- Every ANK/PANEL ledger card keeps original source digits separately in `od`.
- T1/T2/T3 always calculate from `od` when a trick is already applied.
- User can switch directly: T1 -> T2 -> T3 without Undo.
- Undo still restores the original 10 digits.
- New scrape/combo/manual 10-digit input replaces old original source and clears old trick state.
- Manual custom short edit clears old trick source so stale T1/T2/T3 cannot leak back.

Scope:
- Admin ledger cards
- VIP synced ledger cards
- Scrape digits
- Combo scrape
- Smart AI paste
- Manual digit input

Manual overwrite behavior remains active:
- `/save` uses base-file style direct admin overwrite.
- No Firebase Data Guard stale-block is reintroduced.
