# Titan v36.1 — Firebase Data Guard Crash Fix

## Issue fixed
After v36, both Flask and Gateway crashed during startup:

- Flask: `NameError: name 'admin_required' is not defined`
- Gateway: `ReferenceError: authMiddleware is not defined`

## Fix
- Added safe `admin_required()` compatibility decorator in Flask.
- Replaced invalid Gateway `authMiddleware` route reference with existing `gatewayAuthMiddleware`.
- Firebase Data Guard v36 behavior remains unchanged.
- No data reset logic changed except preventing startup crash.

## Validation
- `python3 -m py_compile flask_app.py` passes.
- `node --check Gateway.js` passes.

## Deploy
```bash
titan update /sdcard/Download/titan_firebase_data_guard_crash_fix_v36_1.zip
titan restart
```

## Test
```bash
curl -i http://127.0.0.1:5000/
curl -i -H "X-Titan-Admin-Token: $TITAN_ADMIN_TOKEN" http://127.0.0.1:5000/api/firebase_data_guard_status
curl -i -H "X-Titan-Admin-Token: $TITAN_ADMIN_TOKEN" http://127.0.0.1:3000/firebase_data_guard_status
```
