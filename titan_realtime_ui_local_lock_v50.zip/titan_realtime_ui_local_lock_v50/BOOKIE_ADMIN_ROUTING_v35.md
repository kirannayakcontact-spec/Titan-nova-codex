# TITAN v35 — Bookie/Admin Work Group Routing

## Problem checked in script
Current WhatsApp role routing had only four market-wise roles:

- Ledger Schedule
- Game Entry
- Results
- Forward/Load

Missing role:

- Bookie/Admin Work group

Because of this, bookie/admin management alerts could mix with Forward/Load or old admin notification targets.

## Added

### 1. New market-wise role
Each market now supports:

- `bookieTargets`

UI label:

- Bookie/Admin Work

### 2. Market tab UI
Inside every market card:

- Ledger Schedule
- Game Entry
- Results
- Forward/Load
- Bookie/Admin Work

### 3. Direct Add Full Market
Direct Add form now has:

- Bookie/Admin work group optional

### 4. Backend support
`/api/market_action` now accepts `set_role_targets` with:

- `bookie`
- `admin`

Both map to `bookieTargets`.

### 5. Gateway support
Gateway now recognizes market role:

- `bookie`
- `admin`

Bookie/Admin targets are used for admin/business notifications before old fallback admin targets.

### 6. Load/Forward fallback
Scheduled load forwarder now checks:

1. Forward/Load targets
2. Bookie/Admin Work targets
3. Old load forwarder targets

### 7. Status endpoints
Flask:

- `/api/bookie_admin_routing_status`

Gateway:

- `/bookie_admin_routing_status`

`/api/whatsapp_role_routing_status` and `/whatsapp_role_routing_status` now include `bookie` role counts.

## Rules

- Game entries remain locked to Game Entry group.
- Results remain locked to Results group.
- Ledger schedule remains locked to Ledger Schedule group.
- Forward/load reports prefer Forward/Load group.
- Bookie/Admin Work is separate and safe for management/alerts.
- Blank target keeps old/global behavior.

## Validation

- `python3 -m py_compile flask_app.py`
- `node --check Gateway.js`
