# v26 Lite Core Cleanup

Purpose: reduce script size by removing optional dashboards/report pages and their backend APIs.

Removed/disabled from Flask:
- Admin Hub and Mobile Hub standalone pages
- Observability dashboard/API
- Data Cleanup dashboard/API
- User Safety dashboard/API
- WhatsApp Reliability dashboard proxy/API
- Wallet Statement dashboard/API
- Payment Verification dashboard/API
- Withdrawal Risk dashboard/API
- Result Audit dashboard/API
- Ledger Pro dashboard/API
- v25 pro-panel inline cards inside existing tabs

Kept core systems:
- Main admin app and VIP app
- Ledger + auto-rate + recovery-rate
- Schedule persistence/save fixes
- Payment core submit/approve/reject
- Withdrawal core actions
- Wallet core
- Result/settlement core
- WhatsApp Gateway proxy/core controls
- Security token system
- Money atomicity guards
- Gateway durability and config/env cleanup

Line reduction:
- flask_app.py: 14947 → 12696 lines
- Gateway.js: 5257 → 5190 lines

Deploy:
```bash
titan update /sdcard/Download/titan_lite_core_cleanup_v26.zip
titan restart
```

Important: this is a cleanup build. Optional dashboards are intentionally removed; core workflows remain.
