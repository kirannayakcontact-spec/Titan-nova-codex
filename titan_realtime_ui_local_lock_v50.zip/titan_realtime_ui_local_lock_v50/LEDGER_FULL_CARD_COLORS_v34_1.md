# v34.1 Ledger Full Card Colors

## What changed
- Ledger card color now applies to the full card background, not only the left border/accent.
- The color remains stable and deterministic from `type + market key + index`.
- Future markets automatically receive their own full-card color.
- Inputs, labels, inner stat boxes, and light buttons now use translucent contrast styling so the full color remains visible but text stays readable.

## Safety
- No Firebase schema change.
- No ledger logic change.
- No schedule/rate/recovery/payment/withdrawal/result/Gateway logic change.

## Status endpoint
`/api/ledger_card_color_status`

Expected flags:
- `ledgerCardColorFix: true`
- `fullCardColor: true`
- `version: v34.1-ledger-full-card-colors`
