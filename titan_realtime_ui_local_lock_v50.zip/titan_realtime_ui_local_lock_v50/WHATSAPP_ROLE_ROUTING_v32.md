# v32 — WhatsApp Role Routing

## Goal
Market-wise WhatsApp targets ko role-wise split kiya gaya:

- Ledger Schedule group
- Game Entry group
- Results group
- Forward/Load group

Blank role target old/global behavior use karega, taaki existing setup break na ho.

## Market UI
Market card me `WhatsApp Role Routing` section add hai. Har role ke liye Choose button available hai.

## Gateway behavior
- Entry: market entry target match na ho to entry reject.
- Schedule: market `scheduleTargets` set ho to ledger schedule wahi jayega; blank ho to old card/global schedule targets.
- Result: market `resultTargets` set ho to result wahi jayega; blank ho to old global result/forward targets.
- Forward/Load: market `forwardTargets` set ho to scheduled load report wahi jayega; blank ho to old loadForwarder targets.

## APIs
- Flask: `/api/whatsapp_role_routing_status`
- Gateway: `/whatsapp_role_routing_status`

## Compatibility
Old `entryTargets` and global target behavior preserved.
