# v30 — Market Entries + WhatsApp Target Mapping

## Purpose
Market direct add now also controls Entries, not only Ledger/Results/Auto P/F/Schedule.

## Added
- Market registry item fields:
  - `entryEnabled`
  - `entryTargets`
- Entry settings maps:
  - `entrySettings.marketTargets`
  - `entrySettings.marketEntryEnabled`
- New status endpoint:
  - `/api/market_entry_target_status`

## Admin UI
Market tab now includes:
- Direct Add Full Market form with Entries checkbox
- Optional Entry WhatsApp target field
- Per-market Entry WhatsApp Targets selector

## Gateway behavior
- If a market has entry targets, WhatsApp entry cards for that market are accepted only from those targets.
- If target list is blank, old behavior remains: allowed groups can send entries.
- If `entryEnabled` is OFF for the market, Gateway rejects entries for that market.

## Core logic untouched
- Wallet debit logic unchanged.
- Entry parser card format unchanged.
- Ledger auto-rate/recovery unchanged.
- Payment/withdrawal/result logic unchanged.
